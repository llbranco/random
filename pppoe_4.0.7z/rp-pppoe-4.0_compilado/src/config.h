/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */
/* SPDX-License-Identifier: GPL-2.0-or-later */

#define HAVE_STRUCT_SOCKADDR_LL 1

/* Define if you have kernel-mode PPPoE in Linux file.  */
/* #undef HAVE_LINUX_KERNEL_PPPOE */

/* Define if you have the <linux/if_packet.h> header file.  */
#define HAVE_LINUX_IF_PACKET_H 1

/* Define if you have the <linux/if_pppox.h> header file.  */
#define HAVE_LINUX_IF_PPPOX_H 1

/* Define if you have the <net/if_arp.h> header file.  */
#define HAVE_NET_IF_ARP_H 1

/* Define if you have the <net/ethernet.h> header file.  */
#define HAVE_NET_ETHERNET_H 1

/* Define if you have the <linux/if.h> header file.  */
#define HAVE_LINUX_IF_H 1

/* Define if you have the <sys/uio.h> header file.  */
#define HAVE_SYS_UIO_H 1

/* Define if you have the N_HDLC line discipline in pty.h */
#define HAVE_N_HDLC 1

/* Define to include debugging code */
#define DEBUGGING_ENABLED 1
